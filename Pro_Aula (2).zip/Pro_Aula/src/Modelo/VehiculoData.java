/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class VehiculoData {
private static ArrayList<Vehiculo> listaVehiculos = new ArrayList<>();

    public static void agregarVehiculo(Vehiculo v) {
        listaVehiculos.add(v);
    }

    public static Vehiculo buscarPorPlaca(String placa) {
        for (Vehiculo v : listaVehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                return v;
            }
        }
        return null;
    }

    public static ArrayList<Vehiculo> obtenerTodos() {
        return listaVehiculos;
    }
}
