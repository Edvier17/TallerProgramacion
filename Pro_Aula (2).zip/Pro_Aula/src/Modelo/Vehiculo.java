/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author User
 */
public class Vehiculo {
     private String placa;
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private String tipo;
    private String estado;

    // Constructor
    public Vehiculo(String placa, String marca, String modelo, String color, double precio, String tipo, String estado) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.tipo = tipo;
        this.estado = estado;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    

    // Getters
    public String getPlaca() {
        return placa;
    }
     public String toString() {
        return "Tipo: " + tipo + "\nPlaca: " + placa + "\nMarca: " + marca +
               "\nModelo: " + modelo + "\nColor: " + color + "\nPrecio: " + precio +
               "\nEstado: " + estado;
    }

}